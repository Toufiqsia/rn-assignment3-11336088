import React, { useState } from 'react';
import { View, FlatList, Text, StyleSheet, ScrollView, TextInput, Button, Image, Alert, TouchableOpacity } from 'react-native';

const TaskItem = ({ task, onPress }) => (
  <TouchableOpacity style={styles.taskContainer} onPress={() => onPress(task)}>
    {task.image && <Image source={{ uri: task.image }} style={styles.taskIcon} />}
    <Text style={styles.taskText}>{task.text}</Text>
  </TouchableOpacity>
);

const Category = ({ category, tasks, onTaskPress }) => (
  <View style={styles.categoryContainer}>
    <Text style={styles.categoryTitle}>{category}</Text>
    {tasks.length > 0 ? (
      <FlatList
        data={tasks}
        renderItem={({ item }) => <TaskItem task={item} onPress={onTaskPress} />}
        keyExtractor={(item, index) => index.toString()}
      />
    ) : (
      <Text style={styles.noTasksText}>No tasks available</Text>
    )}
  </View>
);

const App = () => {
  const [newTask, setNewTask] = useState('');
  const [tasks, setTasks] = useState([
    { text: 'Read Chapter 1: Introduction to Web Development', image: 'https://your-hosted-image-url.com/DCIT-202-Assignment-3.png' },
    { text: 'Complete Assignment 1: HTML Basics', image: 'https://your-hosted-image-url.com/Frame-1.png' },
    { text: 'Watch Lecture: CSS Fundamentals', image: 'https://your-hosted-image-url.com/Group-9.png' },
    { text: 'Participate in Forum Discussion: Web Design Trends', image: 'https://your-hosted-image-url.com/Ongoing-Tasks-Cards.png' },
    { text: 'Submit Project Proposal: Personal Portfolio Website', image: 'https://your-hosted-image-url.com/Ongoing-Tasks-Cards-1.png' },
    { text: 'Exercise for 30 minutes', image: 'https://your-hosted-image-url.com/Ongoing-Tasks-Cards-2.png' },
    { text: 'Write code for new feature', image: 'https://your-hosted-image-url.com/Search.pdf' },
    { text: 'Cook dinner', image: 'https://your-hosted-image-url.com/Task.pdf' },
    { text: 'Study for exams', image: 'https://your-hosted-image-url.com/young-woman-working-at-desk.png' },
    { text: 'Clean the house', image: 'https://your-hosted-image-url.com/young-woman-working-online.png' },
    { text: 'Grocery shopping', image: 'https://your-hosted-image-url.com/young-woman-working-at-desk.png' },
    { text: 'Respond to emails', image: 'https://your-hosted-image-url.com/young-woman-working-online.png' },
    { text: 'Plan the week ahead', image: 'https://your-hosted-image-url.com/young-woman-working-at-desk.png' },
    { text: 'Read a book', image: 'https://your-hosted-image-url.com/young-woman-working-online.png' },
    { text: 'Water the plants', image: 'https://your-hosted-image-url.com/young-woman-working-at-desk.png' }
  ]);

  const categories = [
    { category: 'Study', tasks: tasks.slice(0, 3) },
    { category: 'Code', tasks: tasks.slice(3, 6) },
    { category: 'Exercise', tasks: tasks.slice(6, 9) },
    { category: 'Cook', tasks: tasks.slice(9, 12) },
    { category: 'Household', tasks: tasks.slice(12, 15) }
  ];

  const addTask = () => {
    if (newTask.trim()) {
      setTasks(prevTasks => [...prevTasks, { text: newTask.trim(), image: 'https://your-hosted-image-url.com/default.png' }]);
      setNewTask('');
      Alert.alert('Success', 'Task added successfully');
    } else {
      Alert.alert('Error', 'Task cannot be empty');
    }
  };

  const handleTaskPress = (task) => {
    Alert.alert('Task Selected', `You selected: ${task.text}`);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Task Manager</Text>
        <Image source={{ uri: 'https://your-hosted-image-url.com/Frame-1.png' }} style={styles.headerImage} />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="New Task"
          value={newTask}
          onChangeText={setNewTask}
        />
        <Button title="Add Task" onPress={addTask} />
      </View>
      {categories.map((cat, index) => (
        <Category key={index} category={cat.category} tasks={cat.tasks} onTaskPress={handleTaskPress} />
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f7',
    paddingTop: 50,
    paddingHorizontal: 20
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#333'
  },
  headerImage: {
    width: 40,
    height: 40,
    marginLeft: 10
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    alignItems: 'center'
  },
  input: {
    flex: 1,
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    marginRight: 10,
    borderRadius: 5,
    backgroundColor: '#fff'
  },
  categoryContainer: {
    marginBottom: 30
  },
  categoryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#444'
  },
  taskContainer: {
    padding: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1
  },
  taskText: {
    fontSize: 16,
    color: '#333'
  },
  taskIcon: {
    width: 40,
    height: 40,
    marginRight: 10,
    borderRadius: 20
  },
  noTasksText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
    marginTop: 10
  }
});

export default App;
